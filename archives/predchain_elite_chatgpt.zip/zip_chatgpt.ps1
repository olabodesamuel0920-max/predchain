$items = Get-ChildItem -Path . -Exclude ".next", "node_modules", ".git", "*.zip", "tmp", ".DS_Store", ".env", "console.error(e.message))'", "console.log(JSON.stringify({" -ErrorAction SilentlyContinue
Compress-Archive -Path $items -DestinationPath "predchain_elite_chatgpt.zip" -Force
