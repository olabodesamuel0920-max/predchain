'use client';

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { signup } from '@/app/actions/auth';

function SignupForm() {
  const searchParams = useSearchParams();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPending, setIsPending] = useState(false);
  const [referralCode, setReferralCode] = useState('');

  useEffect(() => {
    const ref = searchParams.get('ref');
    if (ref) setReferralCode(ref);
  }, [searchParams]);

  const signupAction = async (formData: FormData) => {
    setIsPending(true);
    setErrorMsg(null);
    
    const returnTo = searchParams.get('returnTo');
    if (returnTo) formData.append('returnTo', returnTo);
    
    // Ensure referral_code is included even if read-only
    if (!formData.get('referral_code') && referralCode) {
      formData.append('referral_code', referralCode);
    }
    
    const res = await signup(formData);
    if (res?.error) {
      setErrorMsg(res.error);
      setIsPending(false);
    }
  };

  const returnTo = searchParams.get('returnTo');
  const loginUrl = returnTo ? `/login?returnTo=${encodeURIComponent(returnTo)}` : '/login';

  return (
    <div className="w-full max-w-[390px] relative z-10 px-4">
      <div className="mb-20 text-center">
        <h2 className="font-display text-3xl font-black text-white mb-4 uppercase italic tracking-tight">Create Account</h2>
        <p className="text-[10px] text-muted font-bold uppercase tracking-[0.2em] italic opacity-60">Join PredChain today.</p>
      </div>

      <form action={signupAction} className="flex flex-col gap-3">
        {errorMsg && (
          <div className="p-10 mb-2 bg-danger/10 border border-danger/20 rounded-xl text-danger text-[9px] font-black uppercase tracking-widest text-center animate-slide-up">
            {errorMsg}
          </div>
        )}
        <div className="grid grid-cols-2 gap-3 px-2">
          <div className="flex flex-col gap-1.5">
            <label className="text-[9px] font-black text-muted uppercase tracking-[0.2em]">Full Name</label>
            <input name="full_name" type="text" required placeholder="John Doe" className="input-premium py-11 px-12" />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[9px] font-black text-muted uppercase tracking-[0.2em]">Username</label>
            <input name="username" type="text" required placeholder="striker1" className="input-premium py-11 px-12" />
          </div>
        </div>

        <div className="flex flex-col gap-1.5 px-2">
          <label className="text-[9px] font-black text-muted uppercase tracking-[0.2em]">Email Address</label>
          <input name="email" type="email" required placeholder="name@email.com" className="input-premium py-11 px-12" />
        </div>

        <div className="flex flex-col gap-1.5 px-2">
          <label className="text-[9px] font-black text-muted uppercase tracking-[0.2em]">Phone Number</label>
          <input name="phone" type="tel" required placeholder="+234..." className="input-premium py-11 px-12" />
        </div>

        <div className="grid grid-cols-2 gap-3 px-2">
          <div className="flex flex-col gap-1.5">
            <label className="text-[9px] font-black text-muted uppercase tracking-[0.2em]">Password</label>
            <input name="password" type="password" required placeholder="••••••••" className="input-premium py-11 px-12" />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[9px] font-black text-muted uppercase tracking-[0.2em]">Referral Link</label>
            <input 
              name="referral_code" 
              type="text" 
              placeholder="Optional" 
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value)}
              className="input-premium py-11 px-12" 
            />
          </div>
        </div>

        <button 
          type="submit" 
          disabled={isPending} 
          className="btn btn-primary w-full mt-4 py-12 font-black uppercase tracking-[0.27em] text-[10px] shadow-xl shadow-gold/10"
        >
          {isPending ? 'Creating Account...' : 'Sign Up'}
        </button>
      </form>

      <p className="text-center text-[10px] text-muted font-bold uppercase tracking-widest mt-16">
        Already have an account? <Link href={loginUrl} className="text-gold hover:text-white transition-colors">Sign In</Link>
      </p>
    </div>
  );
}

export default function SignupPage() {
  return (
    <div className="min-h-screen flex bg-primary overflow-hidden">
      
      {/* LEFT: CINEMATIC ART */}
      <div className="auth-pane-left">
        <div className="absolute inset-0 bg-secondary z-0" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-grad-aurora filter blur-[140px] opacity-20 rounded-full z-1" />
        <div className="absolute inset-0 opacity-[0.03] z-1" style={{ backgroundImage: 'radial-gradient(#FFF 1px, transparent 1px)', backgroundSize: '32px 32px' }} />

        <div className="relative z-10 p-32 md:p-64 max-w-[600px]">
          <Link href="/" className="inline-flex items-center gap-12 mb-32 group">
            <div className="w-10 h-10 bg-grad-gold rounded-xl flex items-center justify-center text-black font-black text-lg shadow-lg group-hover:scale-105 transition-transform">P</div>
            <span className="font-display text-xl font-black text-white uppercase tracking-tighter italic">PredChain</span>
          </Link>
          
          <h1 className="font-display text-5xl font-black text-white leading-[1.05] mb-16 uppercase italic tracking-tighter">
            Join the <br />
            <span className="text-gold">Platform.</span>
          </h1>
          <p className="text-lg text-muted font-bold leading-relaxed uppercase tracking-widest italic opacity-60">
            Build your streak. <br />
            Unlock rewards. <br />
            Master the arena.
          </p>
        </div>
      </div>

      {/* RIGHT: AUTH FORM */}
      <div className="flex-1 flex items-center justify-center p-8 relative z-10">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-gold/5 filter blur-[120px] pointer-events-none" />
        
        <Suspense fallback={<div className="text-muted font-black uppercase tracking-widest text-[10px] animate-pulse">Loading...</div>}>
          <SignupForm />
        </Suspense>
      </div>
    </div>
  );
};
